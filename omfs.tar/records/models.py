from django.db import models
from django.core.urlresolvers import reverse

class Patient(models.Model):
    name = models.CharField(max_length=200)
    pid = models.IntegerField(max_length=15)
    date_of_birth = models.DateField()
    medical_history = models.TextField()
    presentation_date = models.DateField()
    presentation = models.TextField()

    def get_absolute_url(self):
        return reverse('records:detail', kwargs={'pk': self.pk})

    def __str__(self):
        return self.name


class Visit(models.Model):
    patient = models.ForeignKey(Patient, on_delete=models.CASCADE)
    visit_date = models.DateField()
    visit_note = models.TextField()

    def __str__(self):
        return str(self.visit_date)

class Image(models.Model):
    visit = models.ForeignKey(Visit, on_delete=models.CASCADE)
    image = models.FileField()